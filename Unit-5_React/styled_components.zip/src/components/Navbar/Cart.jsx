import { useContext } from "react"
import { CartContext } from "../../Contexs/CartContextProvider"


export const Cart =()=>{
const { cart} = useContext(CartContext)
    return(
       <div>
         <h4> 
         cart:{cart}</h4> 
       </div>
    )
}