import { useContext } from "react"
import { CartContext } from "../../Contexs/CartContextProvider"



export const Button =()=>{

    const {handleCart} = useContext(CartContext)
    return (
        <button
        onClick={()=>{
            handleCart(1)
        }}
        >
            Add to cart
        </button>
    )
}