export const Contact =()=>{
    return(

        <h1>
            1234
        </h1>
    )
}