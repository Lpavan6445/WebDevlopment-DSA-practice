export const Home =()=>{
    return(

        <h1>
            Welcome
        </h1>
    )
}