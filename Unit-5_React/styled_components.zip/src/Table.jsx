
import styled  from "styled-components"


// export const Table =()=>{




//     return <div>


//     </div>
// }

export const Table = styled.table`
    width: 80%;
    color: black;
    text-align: center;
    font-size: 35px;
    font-weight: 300;
  
   
    &>tbody>tr:nth-child(odd){
      
         background-color: teal;
        height: 100px;
        padding: 0px 1px; 
    }
    &>thead{ 
        font-weight: bold;
        height: 100px;
        background-color: red;
    }
    
    &>tbody>tr:nth-child(even){
       
         background-color:white;
        height: 100px;
        padding: 0px 1px; 
        color:blue;
    } 
    &>thead>tr>th:first-child{
        border-top-left-radius: 15px ;
    }
    &>thead>tr>th:last-child{
        border-top-right-radius: 15px ;  
    } 
   
    & > thead > tr:hover , & > tbody > tr:hover {
       
        color: grey;
       
        font-weight: bold;
    }`