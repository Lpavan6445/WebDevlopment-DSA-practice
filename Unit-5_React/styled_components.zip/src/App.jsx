import logo from './logo.svg';
import './App.css';
import { Button } from './components/Body/Button';
import {Cart} from './components/Navbar/Cart'
import { Table } from './Table';
import {useEffect,useState} from 'react'
// import {Home} from './components/Home'
// import {Navbar} from './components/Navbar/Navbar'
// import {Routes,Route} from 'react-router-dom'
// import { Contact } from './components/Contact';
// import { About } from './components/About';
// import { Users } from './components/Users';
// import { UserDetails } from './components/Userdetails';
function App() {


  const [count, setCount] = useState(0); 
  
  let data = [
    {
      name: "MAnohar",
      age:21,
      team:"rcb"
    },{
      name: "vikas",
      age:22,
      team:"srh"
    },
    {
      name: "vinay",
      age:25,
      team:"dc"
    },{
      name: "sandhan",
      age:30,
      team:"csk"
    },
   
  ]



  return (
    <div className="App">
      {/* <Cart />
      <Button/> */}
  
  <Table count={count}>
       <thead>
            <tr>
               <th>Rank</th>
               <th>Name</th>
               <th>Age</th>
               <th>Team</th>
            </tr>
         </thead>
         <tbody>
          
         {data.map((item, index)=>{ 
              return (
                    <tr>
                      <td>{index+1}</td>
                      <td>{item.name}</td>
                      <td>{item.age}</td>
                      <td>{item.team}</td>
                    </tr>
              )
         })
         }
     </tbody> 
       </Table>
    {/* <Navbar  />
    <Routes>
      <Route  path='/' element={<Home/>}></Route>
      <Route  path='/about' element={<About/>}></Route>
      <Route  path='/contact' element={<Contact/>}></Route>
      <Route  path='/users' element={<Users/>}></Route>
      <Route  path='/users/:userid' element={<UserDetails/>}></Route>
    </Routes> */}

    </div>
  );
}

export default App;
