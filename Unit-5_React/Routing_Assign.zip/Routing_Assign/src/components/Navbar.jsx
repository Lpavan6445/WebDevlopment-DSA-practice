import { Link } from "react-router-dom";

import "./mystyle.css"


export const Navbar = () => {



  return (
    <div className="t">
      <Link className="l"  to="/">Home</Link>
      <Link className="l" to="/products" >
        Products list
      </Link>
    </div>
  );
};

// const StyledLink = styled(Link)``
